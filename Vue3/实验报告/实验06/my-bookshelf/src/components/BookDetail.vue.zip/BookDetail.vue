<script setup>

// 定义组件属性

// 定义组件事件

</script>

<template>
  <div class="book-detail">
    <!-- 书籍详细信息，并提供一个关闭按钮 -->
  </div>
</template>

<style scoped>
.book-detail {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background-color: white;
  padding: 20px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
  z-index: 1000;
}
</style>